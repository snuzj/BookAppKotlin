package com.snuzj.bookapp.application

object Constaints {

    const val MAX_BYTE_PDF = 50000000 //50mb, can change any size

}